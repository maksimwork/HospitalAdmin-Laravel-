<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Http\Controllers\Controller;
use App\Http\Requests;
use Illuminate\Support\Facades\Validator;
use Auth;
use Illuminate\Support\Facades\Redirect;

class HomeController extends Controller
{
    
    // public function __construct()
    // {
    //     $this->middleware('auth');
    // }

    public function index()
    {
       
        $patient = DB::table('patient')->get()->count();
        $category = DB::table('category')->get()->count();
        $exercise = DB::table('exercise')->get()->count();
        $training = DB::table('training')->get()->count();
        if(Auth::user()->privillege == 2)
        {
            $patientresult = DB::table('patient')
                ->where('patientname',Auth::user()->name)
                ->first();
            if($patientresult->portal == 1)
            {
               
                return view('home')->with('patient',$patient)->with('training',$training)->with('exercise',$exercise)->with('category',$category);
            }
            else{
                return Redirect::to('/logout');
            }
        }
        elseif(Auth::user()->privillege == 3)
        {
            $physioresult = DB::table('employee')
            ->where('employeename',Auth::user()->name)
            ->first();
            // dd(Auth::user()->name);
            if($physioresult->portal == 1)
            {
                // dd("physio1login");
                return view('home')->with('patient',$patient)->with('training',$training)->with('exercise',$exercise)->with('category',$category);
            }
            else{
                return Redirect::to('/logout');
            }
        }
        else if(Auth::user()->privillege == 1)
        {
        // $patient = DB::table('patient')->get()->count();
        // $category = DB::table('category')->get()->count();
        // $exercise = DB::table('exercise')->get()->count();
        // $training = DB::table('training')->get()->count();
        return view('home')->with('patient',$patient)->with('training',$training)->with('exercise',$exercise)->with('category',$category);
        }
    }

    
}
