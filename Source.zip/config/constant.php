<?php

return [
    'patientname' => 'test',
    'physioname' => 'test',
    'token' => 'abc',
];

