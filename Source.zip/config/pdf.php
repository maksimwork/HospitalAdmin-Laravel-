<?php

return [
	'mode'                  => 'utf-8',
	'format'                => 'B5',
	'author'                => '',
	'subject'               => '',
	'keywords'              => '',
	'creator'               => 'Adam Vital',
	'display_mode'          => 'fullpage'
];

