<html>
<head>
<title>Admin Vital - 404 Error - Document Not Found</title>
</head>

<body>

<h1>404 - Document Not Found</h1>
<p>

<blockquote>

The requested object or URL, &nbsp; <b><!--#echo var="REDIRECT_URL"--></b>   
was not found on this server.<P>

The link you followed is either outdated, inaccurate, or the server has been
instructed not to let you have it.<P>

Please inform the administrator of the referring page, 
<a href="#"><!--#echo var="HTTP_REFERER"--></a>.

</blockquote>

                                                                 
</body>
</html>                 