<?php echo $__env->make('head', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <body>
        <div class="preloader">
            <div class="cssload-speeding-wheel">
            </div>
        </div>

        <section id="wrapper" class="login-register">
            <div class="login-box">
                <div class="white-box">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                    <form class="form-horizontal" method="POST" action="<?php echo e(route('password.email')); ?>">
                        <?php echo e(csrf_field()); ?>

                        <div class="form-group">
                            <div class="col-xs-12">
                                <h3>Recover Password</h3>
                                <p class="text-muted">Enter your Email and instructions will be sent to you! </p>
                            </div>
                        </div>
                        <div class="form-group<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
                            <div class="col-xs-12">
                                <input id="email" type="email" class="form-control" name="email" value="<?php echo e(old('email')); ?>" required>
                                <?php if($errors->has('email')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('email')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                    
                        <div class="form-group text-center m-t-20">
                            <div class="col-xs-12">
                                <button type="submit" class="btn btn-primary btn-lg btn-block text-uppercase waves-effect waves-light">Send Password Reset Link</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </section>
    <body>
    
<?php echo $__env->make('script', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</html>


