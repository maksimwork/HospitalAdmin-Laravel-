<tr>
    <td class="header">
        <img src="http://18.218.188.239/adam.png" alt="" class="logo" />
        <!-- <p> dsaklfadsklfjadsklfjdsaklfjdsklf</p>
        <a href="<?php echo e($url); ?>">
            
        </a> -->
    </td>
</tr>
