<?php echo $__env->make('head', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<body>
    <!-- Preloader -->
    <div class="preloader">
        <div class="cssload-speeding-wheel"></div>
    </div>
    <div id="wrapper">
        <!-- Top Navigation -->
        <?php echo $__env->make('topnavbar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>;
        <?php echo $__env->make('sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <!-- Left navbar-header end -->

        <!-- Page Content -->
        <div id="page-wrapper">
            <div class="container-fluid">
                <div class="row bg-title">
                    <div class="col-lg-3 col-md-4 col-sm-4 col-xs-12">
                        <h4 class="page-title">Edit Role</h4> 
                    </div>
                    <div class="col-lg-9 col-sm-8 col-md-8 col-xs-12"> 
                        
                        <ol class="breadcrumb">
                            <li><a href="javascript:void(0);">System Management</a></li>
                            <li class="active">Edit Role</li>
                        </ol>
                    </div>
                </div>   
                
                <div class="row">
                    <div class="col-sm-12">
                        <div class="white-box">
                        <div class="table-responsive m-t-40">
                            <table class="table borderlesstable">
                                <thead>
                                    <tr style = "background-color:rgb(245, 245, 245);">
                                        <td style = "padding-left:30px">Module</td>
                                        <td>View</td>
                                        <td>Add</td>
                                        <td>Edit</td>
                                        <td >Delete</td>
                                        <td>Share</td>
                                    </tr>
                                </thead>
                                <tbody style="cursor: pointer;" >
                                    <input type="hidden" class="priv" value=<?php echo e($roletype); ?>>

                                    <?php for($i = 0; $i < 7; $i ++): ?>
                                        <tr class="head">
                                            <?php if($i == 0): ?>
                                                <td style = "padding-left:30px">Library</td>
                                                <td >
                                                    <div class="checkbox checkbox-info" style = "margin : 0 0;">
                                                        <input class="view" type="checkbox" value=<?php echo e($i); ?> 
                                                                <?php if($library->view == 1): ?> <?php echo e("checked"); ?> 
                                                                <?php elseif($library->view == 0): ?> <?php echo e(""); ?> 
                                                                <?php endif; ?>>
                                                        <label></label>
                                                    </div>
                                                </td>

                                                <td>
                                                    <div class="checkbox checkbox-info" style = "margin : 0 0;">
                                                        <input class="add" type="checkbox" value=<?php echo e($i); ?>

                                                                    <?php if($library->add == 1): ?> <?php echo e("checked"); ?> 
                                                                    <?php elseif($library->add == 0): ?> <?php echo e(""); ?> 
                                                                    <?php endif; ?>>
                                                        <label> </label>
                                                    </div>
                                                </td>

                                                <td>
                                                    <div class="checkbox checkbox-info" style = "margin : 0 0;">
                                                        <input class="edit" type="checkbox" value=<?php echo e($i); ?>

                                                                    <?php if($library->edit == 1): ?> <?php echo e("checked"); ?> 
                                                                    <?php elseif($library->edit == 0): ?> <?php echo e(""); ?> 
                                                                    <?php endif; ?>>
                                                        <label> </label>
                                                    </div>
                                                </td>
                                                
                                                <td>
                                                    <div class="checkbox checkbox-info" style = "margin : 0 0;">
                                                        <input class="delete" type="checkbox" value=<?php echo e($i); ?>

                                                                    <?php if($library->delete == 1): ?> <?php echo e("checked"); ?> 
                                                                    <?php elseif($library->delete == 0): ?> <?php echo e(""); ?> 
                                                                    <?php endif; ?>>
                                                        <label> </label>
                                                    </div>
                                                </td>

                                                <td>
                                                    <div class="checkbox checkbox-info" style = "margin : 0 0;">
                                                        <input class="share" type="checkbox" value=<?php echo e($i); ?>

                                                                    <?php if($library->share == 1): ?> <?php echo e("checked"); ?> 
                                                                    <?php elseif($library->share == 0): ?> <?php echo e(""); ?> 
                                                                    <?php endif; ?>>
                                                        <label> </label>
                                                    </div>
                                                </td>

                                            <?php elseif($i == 1): ?>
                                                <td style = "padding-left:30px">Patients</td>
                                                <td >
                                                    <div class="checkbox checkbox-info" style = "margin : 0 0;">
                                                        <input class="view" type="checkbox" value=<?php echo e($i); ?> 
                                                                <?php if($patients->view == 1): ?> <?php echo e("checked"); ?> 
                                                                <?php elseif($patients->view == 0): ?> <?php echo e(""); ?> 
                                                                <?php endif; ?>>
                                                        <label></label>
                                                    </div>
                                                </td>
                                                <td>
                                                    <div class="checkbox checkbox-info" style = "margin : 0 0;">
                                                        <input class="add" type="checkbox" value=<?php echo e($i); ?>

                                                                    <?php if($patients->add == 1): ?> <?php echo e("checked"); ?> 
                                                                    <?php elseif($patients->add == 0): ?> <?php echo e(""); ?> 
                                                                    <?php endif; ?>>
                                                        <label> </label>
                                                    </div>
                                                </td>

                                                <td>
                                                    <div class="checkbox checkbox-info" style = "margin : 0 0;">
                                                        <input class="edit" type="checkbox" value=<?php echo e($i); ?>

                                                                    <?php if($patients->edit == 1): ?> <?php echo e("checked"); ?> 
                                                                    <?php elseif($patients->edit == 0): ?> <?php echo e(""); ?> 
                                                                    <?php endif; ?>>
                                                        <label> </label>
                                                    </div>
                                                </td>
                                                
                                                <td>
                                                    <div class="checkbox checkbox-info" style = "margin : 0 0;">
                                                        <input class="delete" type="checkbox" value=<?php echo e($i); ?>

                                                                    <?php if($patients->delete == 1): ?> <?php echo e("checked"); ?> 
                                                                    <?php elseif($patients->delete == 0): ?> <?php echo e(""); ?> 
                                                                    <?php endif; ?>>
                                                        <label> </label>
                                                    </div>
                                                </td>

                                                <td>
                                                    <div class="checkbox checkbox-info" style = "margin : 0 0;">
                                                        <input class="share" type="checkbox" value=<?php echo e($i); ?>

                                                                    <?php if($patients->share == 1): ?> <?php echo e("checked"); ?> 
                                                                    <?php elseif($patients->share == 0): ?> <?php echo e(""); ?> 
                                                                    <?php endif; ?>>
                                                        <label> </label>
                                                    </div>
                                                </td>
                                            <?php elseif($i == 2): ?>
                                                <td style = "padding-left:30px">Physiotherapists</td>
                                                <td >
                                                    <div class="checkbox checkbox-info" style = "margin : 0 0;">
                                                        <input class="view" type="checkbox" value=<?php echo e($i); ?> 
                                                                <?php if($physio->view == 1): ?> <?php echo e("checked"); ?> 
                                                                <?php elseif($physio->view == 0): ?> <?php echo e(""); ?> 
                                                                <?php endif; ?>>
                                                        <label></label>
                                                    </div>
                                                </td>
                                                <td>
                                                    <div class="checkbox checkbox-info" style = "margin : 0 0;">
                                                        <input class="add" type="checkbox" value=<?php echo e($i); ?>

                                                                    <?php if($physio->add == 1): ?> <?php echo e("checked"); ?> 
                                                                    <?php elseif($physio->add == 0): ?> <?php echo e(""); ?> 
                                                                    <?php endif; ?>>
                                                        <label> </label>
                                                    </div>
                                                </td>
                                                <td>
                                                    <div class="checkbox checkbox-info" style = "margin : 0 0;">
                                                        <input class="edit" type="checkbox" value=<?php echo e($i); ?>

                                                                    <?php if($physio->edit == 1): ?> <?php echo e("checked"); ?> 
                                                                    <?php elseif($physio->edit == 0): ?> <?php echo e(""); ?> 
                                                                    <?php endif; ?>>
                                                        <label> </label>
                                                    </div>
                                                </td>
                                                
                                                <td>
                                                    <div class="checkbox checkbox-info" style = "margin : 0 0;">
                                                        <input class="delete" type="checkbox" value=<?php echo e($i); ?>

                                                                    <?php if($physio->delete == 1): ?> <?php echo e("checked"); ?> 
                                                                    <?php elseif($physio->delete == 0): ?> <?php echo e(""); ?> 
                                                                    <?php endif; ?>>
                                                        <label> </label>
                                                    </div>
                                                </td>

                                                <td>
                                                    <div class="checkbox checkbox-info" style = "margin : 0 0;">
                                                        <input class="share" type="checkbox" value=<?php echo e($i); ?>

                                                                    <?php if($physio->share == 1): ?> <?php echo e("checked"); ?> 
                                                                    <?php elseif($physio->share == 0): ?> <?php echo e(""); ?> 
                                                                    <?php endif; ?>>
                                                        <label> </label>
                                                    </div>
                                                </td>
                                            <?php elseif($i == 3): ?>
                                                <td style = "padding-left:30px">Training</td>
                                                <td >
                                                    <div class="checkbox checkbox-info" style = "margin : 0 0;">
                                                        <input class="view" type="checkbox" value=<?php echo e($i); ?> 
                                                                <?php if($training->view == 1): ?> <?php echo e("checked"); ?> 
                                                                <?php elseif($training->view == 0): ?> <?php echo e(""); ?> 
                                                                <?php endif; ?>>
                                                        <label></label>
                                                    </div>
                                                </td>
                                                <td>
                                                    <div class="checkbox checkbox-info" style = "margin : 0 0;">
                                                        <input class="add" type="checkbox" value=<?php echo e($i); ?>

                                                                    <?php if($training->add == 1): ?> <?php echo e("checked"); ?> 
                                                                    <?php elseif($training->add == 0): ?> <?php echo e(""); ?> 
                                                                    <?php endif; ?>>
                                                        <label> </label>
                                                    </div>
                                                </td>
                                                <td>
                                                    <div class="checkbox checkbox-info" style = "margin : 0 0;">
                                                        <input class="edit" type="checkbox" value=<?php echo e($i); ?>

                                                                    <?php if($training->edit == 1): ?> <?php echo e("checked"); ?> 
                                                                    <?php elseif($training->edit == 0): ?> <?php echo e(""); ?> 
                                                                    <?php endif; ?>>
                                                        <label> </label>
                                                    </div>
                                                </td>
                                                
                                                <td>
                                                    <div class="checkbox checkbox-info" style = "margin : 0 0;">
                                                        <input class="delete" type="checkbox" value=<?php echo e($i); ?>

                                                                    <?php if($training->delete == 1): ?> <?php echo e("checked"); ?> 
                                                                    <?php elseif($training->delete == 0): ?> <?php echo e(""); ?> 
                                                                    <?php endif; ?>>
                                                        <label> </label>
                                                    </div>
                                                </td>

                                                <td>
                                                    <div class="checkbox checkbox-info" style = "margin : 0 0;">
                                                        <input class="share" type="checkbox" value=<?php echo e($i); ?>

                                                                    <?php if($training->share == 1): ?> <?php echo e("checked"); ?> 
                                                                    <?php elseif($training->share == 0): ?> <?php echo e(""); ?> 
                                                                    <?php endif; ?>>
                                                        <label> </label>
                                                    </div>
                                                </td>
                                            <?php elseif($i == 4): ?>
                                                <td style = "padding-left:30px">Help & Support</td>
                                                <td >
                                                    <div class="checkbox checkbox-info" style = "margin : 0 0;">
                                                        <input class="view" type="checkbox" value=<?php echo e($i); ?> 
                                                                <?php if($help->view == 1): ?> <?php echo e("checked"); ?> 
                                                                <?php elseif($help->view == 0): ?> <?php echo e(""); ?> 
                                                                <?php endif; ?>>
                                                        <label></label>
                                                    </div>
                                                </td>
                                                <td>
                                                    <div class="checkbox checkbox-info" style = "margin : 0 0;">
                                                        <input class="add" type="checkbox" value=<?php echo e($i); ?>

                                                                    <?php if($help->add == 1): ?> <?php echo e("checked"); ?> 
                                                                    <?php elseif($help->add == 0): ?> <?php echo e(""); ?> 
                                                                    <?php endif; ?>>
                                                        <label> </label>
                                                    </div>
                                                </td>
                                                <td>
                                                    <div class="checkbox checkbox-info" style = "margin : 0 0;">
                                                        <input class="edit" type="checkbox" value=<?php echo e($i); ?>

                                                                    <?php if($help->edit == 1): ?> <?php echo e("checked"); ?> 
                                                                    <?php elseif($help->edit == 0): ?> <?php echo e(""); ?> 
                                                                    <?php endif; ?>>
                                                        <label> </label>
                                                    </div>
                                                </td>
                                                
                                                <td>
                                                    <div class="checkbox checkbox-info" style = "margin : 0 0;">
                                                        <input class="delete" type="checkbox" value=<?php echo e($i); ?>

                                                                    <?php if($help->delete == 1): ?> <?php echo e("checked"); ?> 
                                                                    <?php elseif($help->delete == 0): ?> <?php echo e(""); ?> 
                                                                    <?php endif; ?>>
                                                        <label> </label>
                                                    </div>
                                                </td>

                                                <td>
                                                    <div class="checkbox checkbox-info" style = "margin : 0 0;">
                                                        <input class="share" type="checkbox" value=<?php echo e($i); ?>

                                                                    <?php if($help->share == 1): ?> <?php echo e("checked"); ?> 
                                                                    <?php elseif($help->share == 0): ?> <?php echo e(""); ?> 
                                                                    <?php endif; ?>>
                                                        <label> </label>
                                                    </div>
                                                </td>
                                            <?php elseif($i == 5): ?>
                                                <td style = "padding-left:30px">Feedback</td>
                                                <td >
                                                    <div class="checkbox checkbox-info" style = "margin : 0 0;">
                                                        <input class="view" type="checkbox" value=<?php echo e($i); ?> 
                                                                <?php if($feedback->view == 1): ?> <?php echo e("checked"); ?> 
                                                                <?php elseif($feedback->view == 0): ?> <?php echo e(""); ?> 
                                                                <?php endif; ?>>
                                                        <label></label>
                                                    </div>
                                                </td>
                                                <td>
                                                    <div class="checkbox checkbox-info" style = "margin : 0 0;">
                                                        <input class="add" type="checkbox" value=<?php echo e($i); ?>

                                                                    <?php if($feedback->add == 1): ?> <?php echo e("checked"); ?> 
                                                                    <?php elseif($feedback->add == 0): ?> <?php echo e(""); ?> 
                                                                    <?php endif; ?>>
                                                        <label> </label>
                                                    </div>
                                                </td>
                                                <td>
                                                    <div class="checkbox checkbox-info" style = "margin : 0 0;">
                                                        <input class="edit" type="checkbox" value=<?php echo e($i); ?>

                                                                    <?php if($feedback->edit == 1): ?> <?php echo e("checked"); ?> 
                                                                    <?php elseif($feedback->edit == 0): ?> <?php echo e(""); ?> 
                                                                    <?php endif; ?>>
                                                        <label> </label>
                                                    </div>
                                                </td>
                                                
                                                <td>
                                                    <div class="checkbox checkbox-info" style = "margin : 0 0;">
                                                        <input class="delete" type="checkbox" value=<?php echo e($i); ?>

                                                                    <?php if($feedback->delete == 1): ?> <?php echo e("checked"); ?> 
                                                                    <?php elseif($feedback->delete == 0): ?> <?php echo e(""); ?> 
                                                                    <?php endif; ?>>
                                                        <label> </label>
                                                    </div>
                                                </td>

                                                <td>
                                                    <div class="checkbox checkbox-info" style = "margin : 0 0;">
                                                        <input class="share" type="checkbox" value=<?php echo e($i); ?>

                                                                    <?php if($feedback->share == 1): ?> <?php echo e("checked"); ?> 
                                                                    <?php elseif($feedback->share == 0): ?> <?php echo e(""); ?> 
                                                                    <?php endif; ?>>
                                                        <label> </label>
                                                    </div>
                                                </td>
                                            <?php elseif($i == 6): ?>
                                                <td style = "padding-left:30px">System Management</td>
                                                <td >
                                                    <div class="checkbox checkbox-info" style = "margin : 0 0;">
                                                        <input class="view" type="checkbox" value=<?php echo e($i); ?> 
                                                                <?php if($system->view == 1): ?> <?php echo e("checked"); ?> 
                                                                <?php elseif($system->view == 0): ?> <?php echo e(""); ?> 
                                                                <?php endif; ?>>
                                                        <label></label>
                                                    </div>
                                                </td>
                                                <td>
                                                    <div class="checkbox checkbox-info" style = "margin : 0 0;">
                                                        <input class="add" type="checkbox" value=<?php echo e($i); ?>

                                                                    <?php if($system->add == 1): ?> <?php echo e("checked"); ?> 
                                                                    <?php elseif($system->add == 0): ?> <?php echo e(""); ?> 
                                                                    <?php endif; ?>>
                                                        <label> </label>
                                                    </div>
                                                </td>

                                                <td>
                                                    <div class="checkbox checkbox-info" style = "margin : 0 0;">
                                                        <input class="edit" type="checkbox" value=<?php echo e($i); ?>

                                                                    <?php if($system->edit == 1): ?> <?php echo e("checked"); ?> 
                                                                    <?php elseif($system->edit == 0): ?> <?php echo e(""); ?> 
                                                                    <?php endif; ?>>
                                                        <label> </label>
                                                    </div>
                                                </td>
                                                
                                                <td>
                                                    <div class="checkbox checkbox-info" style = "margin : 0 0;">
                                                        <input class="delete" type="checkbox" value=<?php echo e($i); ?>

                                                                    <?php if($system->delete == 1): ?> <?php echo e("checked"); ?> 
                                                                    <?php elseif($system->delete == 0): ?> <?php echo e(""); ?> 
                                                                    <?php endif; ?>>
                                                        <label> </label>
                                                    </div>
                                                </td>

                                                <td>
                                                    <div class="checkbox checkbox-info" style = "margin : 0 0;">
                                                        <input class="share" type="checkbox" value=<?php echo e($i); ?>

                                                                    <?php if($system->share == 1): ?> <?php echo e("checked"); ?> 
                                                                    <?php elseif($system->share == 0): ?> <?php echo e(""); ?> 
                                                                    <?php endif; ?>>
                                                        <label> </label>
                                                    </div>
                                                </td>
                                            <?php endif; ?>
                                        </tr>
                                    <?php endfor; ?>
                                </tbody>
                                </table>
                            </div> 
                        </div>
                    </div>
                </div>

            </div>
            <!-- /.container-fluid -->
            <footer class="footer text-center">   </footer>
        </div>
        <!-- /#page-wrapper -->
    </div>
    <!-- /#wrapper -->
    
    <?php echo $__env->make('script', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</body>

<script>
    $('.view').on('click', function (event) {
        var priv = $('.priv').val();
        location.href =  "/roleupdateview/" + priv +"/" + (parseInt($(this).val()) + 1);
    });
    $('.add').on('click', function (event) {
        var priv = $('.priv').val();
        location.href =  "/roleupdateadd/" + priv +"/" + (parseInt($(this).val()) + 1);
    });
    $('.edit').on('click', function (event) {
        var priv = $('.priv').val();
        location.href =  "/roleupdateedit/" + priv +"/" + (parseInt($(this).val()) + 1);
    });
    $('.delete').on('click', function (event) {
        var priv = $('.priv').val();
        location.href =  "/roleupdatedelete/" + priv +"/" + (parseInt($(this).val()) + 1);
    });
    $('.share').on('click', function (event) {
        var priv = $('.priv').val();
        location.href =  "/roleupdateshare/" + priv +"/" + (parseInt($(this).val()) + 1);
    });
</script>
</html>
