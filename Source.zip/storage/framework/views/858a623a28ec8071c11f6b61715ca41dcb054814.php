<!doctype html>
<html lang="<?php echo e(app()->getLocale()); ?>">
    <head>
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.0/css/bootstrap.min.css">
        <link rel="stylesheet" href="/css/app.css">
        <link href="http://maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css" rel="stylesheet">
        <style>
            .button {
                background-color: #4CAF50;
                border: none;
                color: white;
                padding: 15px 32px;
                text-align: center;
                text-decoration: none;
                display: inline-block;
                font-size: 16px;
                margin: 4px 2px;
                cursor: pointer;
            }
</style>
    </head>

    <body>
        <img src="http://18.218.188.239/adam.png" alt="" class="logo" />

        <div style = "margin-top:30px">
            <p>Dear Client</p>
            
        </div>

        <h1 style="font-style: italic;">Feedback</h1>
        <p> Feedback </p>
    </body>
</html>