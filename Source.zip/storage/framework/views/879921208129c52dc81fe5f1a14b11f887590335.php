<?php echo $__env->make('head', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<body>
    <!-- Preloader -->
    <div class="preloader">
        <div class="cssload-speeding-wheel"></div>
    </div>
    <div id="wrapper">
        <!-- Top Navigation -->
        <?php echo $__env->make('topnavbar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>;
        <?php echo $__env->make('sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <!-- Left navbar-header end -->

        <!-- Page Content -->
        <div id="page-wrapper">
            <div class="container-fluid">
                <div class="row bg-title">
                    <div class="col-lg-3 col-md-4 col-sm-4 col-xs-12">
                        <h4 class="page-title">Demo Exercise - Preview</h4> 
                    </div>
                    <div class="col-lg-9 col-sm-8 col-md-8 col-xs-12"> 
                        
                        <ol class="breadcrumb">
                            <li>
                                <a style = "border-radius:2px;"class = "print ti-printer btn btn-success" style="cursor: pointer;"><span></span>&nbsp; Print</a>
                            </li>
                            <!-- <li>
                                <a style="border-radius: 10px;" class="btn btn-danger icon-eye" href="" role="button"><span></span>&nbsp;Eye</a>
                            </li>    -->
                            <?php if($permission_result[0]->share != "2"): ?>
                            <li>
                                <a href="javascript:void(0);" class = "btn btn-success icon-share" data-toggle="modal" data-target="#responsive-modal" style="border-radius: 2px;">
                                    <span></span>&nbsp;Share
                                </a>
                            </li>
                            <?php endif; ?>
                            <div id="responsive-modal" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" style="display: none;">
                                <div class="modal-dialog">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <!-- <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button> -->
                                            
                                        <div class="modal-body">
                                            <form>
                                                <div class="form-group">
                                                    <label for="recipient-name" class="control-label">Select Patient</label>
                                                    <select class="selectpicker form-control patientlist" id="pickerlist" name="patient" data-live-search = "true">
                                                        <?php $__currentLoopData = $patient; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $patientitem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option name="patient"><?php echo e($patientitem->patientname); ?></option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </select>
                                                </div>
                                                <div class="form-group">
                                                    <label for="message-text" class="control-label">Set Expiry</label>
                                                    <input type="text" id="bdate" name="bdate" class="form-control mydatepicker" placeholder="enter date">
                                                </div>
                                            </form>
                                        </div>
                                        <div class="modal-footer">
                                            <button type="button" class="btn btn-default waves-effect" data-dismiss="modal">Close</button>
                                            <button type="button" class="btn btn-danger waves-effect waves-light shareoption">Save changes</button>
                                        </div>
                                    </div>
                                </div>
                            </div> 
                            
                        </ol>
                    </div>
                </div>   
                
                <div class="row">
                    
                    <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
                        
                    </div>
                    <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                        <div class="white-box">
                            <form class="mainform" action="/" accept-charset="UTF-8">
                                <input type="hidden" id="bdate" name="bdate" class="form-control tempdatepicker" placeholder="enter date" value="">
                                <input type="hidden" id="temppatient" name="bpatient" class="form-control temppatient" value="">
                                <input type="hidden" id="temprepeat" name="repeat" class="form-control temprepeat" value="">
                                <!-- <h3>Hospital Manage</h3> -->
                                <div style="text-align : center;">
                                    <img src="/plugins/images/adam.png" alt="home" />
                                </div>
                                <?php $__currentLoopData = $exercise; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $exerciseitem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <hr></hr>
                                    <div class = "row">
                                        <div class="col-md-4"> 
                                        <?php if($exerciseitem->mediatype == "Picture"): ?>
                                            <img src=<?php echo e($exerciseitem->filelink); ?> class="img-responsive thumbnail mr25"> 
                                        <?php else: ?>
                                            <video class="img-responsive thumbnail mr25" controls>
                                                <source  type="video/mp4" src=<?php echo e($exerciseitem->filelink); ?>>
                                            </video>
                                        <?php endif; ?>
                                        </div>  

                                        <div class="col-md-8"> <?php echo e($exerciseitem->description); ?></p>
                                        </div>
                                        <?php if(Auth::user()->privillege != 2): ?>
                                                      
                                            <div class="col-lg-2 col-md-2 col-sm-2 col-xs-12">
                                                <p>Repeat: </p>
                                            </div>
                                            
                                            <div class="col-lg-1 col-md-1 col-sm-1 col-xs-12">
                                                <button class="btn-block btn-outline btn-default minusbutton">-

                                                    <input type="hidden" class="selectTitle" name=<?php echo e("exerciseindex".$exerciseitem->id); ?> value=<?php echo e($exerciseitem->id); ?>>
                                                </button>
                                            </div>
                                      


                                            <div class="col-lg-1 col-md-1 col-sm-1 col-xs-12" style="display:table;">
                                                <code style = "display:table-cell; text-align:center;" class=<?php echo e($exerciseitem->title); ?> id="itemTitle"><?php echo e($exerciseitem->repeat); ?></code>
                                            </div>
                                            
                                            <div class="col-lg-1 col-md-1 col-sm-1 col-xs-12">
                                                <button class="btn-block btn-outline btn-default plusbutton">+
                                                    <input type="hidden" class="selectTitle" value=<?php echo e($exerciseitem->id); ?>>
                                                </button>
                                            </div>
                                            <?php endif; ?>
                                    </div>
                                    <input type="hidden" name=<?php echo e("check" . $exerciseitem->id); ?> value="checked">
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <hr/>
                                <div class="row">
                                    <div class="col-xs-12">
                                        <p><strong>Support Team</strong></p>
                                        <p>Adam Vital Physiotherapy & rehabilitation center</p>
                                        <p>T: +971 4 2515000 | F: +971 4 2515522</p>
                                        <p>Address: Index Holding Building, Nad Al Hamar Road, Dubai, UAE</p>
                                        <p>P.O. Box 76800</p>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
            <!-- /.container-fluid -->
            <footer class="footer text-center">   </footer>
        </div>
        <!-- /#page-wrapper -->
    </div>
    <!-- /#wrapper -->
    
    <?php echo $__env->make('script', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</body>

<script>
    $(document).ready(function() {
        // function pad(s) {
        //     return (s<10 ? '0' + s : s);
        // }
        // var date = new Date();
        // date.setDate(date.getDate() + 10);
        // var year = pad(date.getFullYear());
        // var month = pad(date.getMonth()+1);
        // var n = pad(date.getDate());
        // input = document.getElementById("bdate");
        // input.value = month +"/"+ n+ "/"+ year;
    });
    $('.minusbutton').click(function(event){
        // var index = $(this).children(".selectTitle").val();
        // var temp =  "/updateminusexercisepreview/" + index;
        // $('.mainform').attr('action',temp);
        var itemValue = $('#itemTitle').text();
        if(itemValue > 0 ){
            $('#itemTitle').text(--itemValue);}
        event.preventDefault();
        // $('.mainform')[0].submit();
    });

    $('.shareoption').click(function(){
        $('.mainform').attr('action','/shareoption');
        $('.tempdatepicker').attr('value',$('.mydatepicker').val());
        $('.temppatient').attr('value',$('#pickerlist').val());
        $('.temprepeat').attr('value',$('#itemTitle').text());
        // alert( $('#itemTitle').text());
       
        $('.mainform')[0].submit();
    });

    $('.plusbutton').click(function(event){
        var index = $(this).children(".selectTitle").val();
        var temp =  "/updateplusexercisepreview/" + index;
        $('.mainform').attr('action',temp);
        var itemValue = $('#itemTitle').text();
        $('#itemTitle').text(++itemValue);
        event.preventDefault();
        // $('.mainform')[0].submit();
    });

    $('.print').click(function(){
        $('.mainform').attr('action','/generatepdf');
        $('.mainform')[0].submit();
    });

</script>
</html>
