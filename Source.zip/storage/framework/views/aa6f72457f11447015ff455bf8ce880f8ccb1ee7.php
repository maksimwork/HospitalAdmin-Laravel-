<?php echo $__env->make('head', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<body>
    <!-- Preloader -->
    <div class="preloader">
        <div class="cssload-speeding-wheel"></div>
    </div>
    <div id="wrapper">
        <!-- Top Navigation -->
        <?php echo $__env->make('topnavbar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>;
        <?php echo $__env->make('sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <!-- Left navbar-header end -->

    <style>
        .wrapper {
            text-align:center;
        }
        .switch {
        position: relative;
        display: inline-block;
        width: 60px;
        height: 34px;
        }

        .switch input {display:none;}

        .slider {
        position: absolute;
        cursor: pointer;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        background-color: #ccc;
        -webkit-transition: .4s;
        transition: .4s;
        }

        .slider:before {
        position: absolute;
        content: "";
        height: 26px;
        width: 26px;
        left: 4px;
        bottom: 4px;
        background-color: white;
        -webkit-transition: .4s;
        transition: .4s;
        }

        input:checked + .slider {
        background-color: #2196F3;
        }

        input:focus + .slider {
        box-shadow: 0 0 1px #2196F3;
        }

        input:checked + .slider:before {
        -webkit-transform: translateX(26px);
        -ms-transform: translateX(26px);
        transform: translateX(26px);
        }

        /* Rounded sliders */
        .slider.round {
        border-radius: 34px;
        }

        .slider.round:before {
        border-radius: 50%;
        }
    </style>



        <!-- Page Content -->
        <div id="page-wrapper">
            <div class="container-fluid">
                <div class="row bg-title">
                    <div class="col-lg-3 col-md-4 col-sm-4 col-xs-12">
                        <h4 class="page-title">Manage Patient</h4> 
                    </div>
                    <div class="col-lg-9 col-sm-8 col-md-8 col-xs-12"> 
                        
                        <ol class="breadcrumb">
                            <li><a href="javascript:void(0);">Library</a></li>
                            <li class="active">Manage Patient</li>
                        </ol>
                    </div>
                </div>   
                
                <div class="row">
                    <div class="col-sm-12">
                        <div class="white-box" style = "display:flex">
                            
                           
                            <h4 class="page-title"><?php echo e($patient->patientfirstname); ?>-<?php echo e($patient->patientlastname); ?></h4> 
                            <!-- <button type="button" class="btn btn-primary">Primary</button> -->
                            <div class="col-md-6 col-md-push-8">
                                <a href = "/patienteditprofile/<?php echo e($patient->id); ?>" class="btn  btn-success" style = " background-color:#0095D4;border-raidus:2px;color:#FFF;">Edit Patient</a>
                                <button type="button" style = "width:100px;background-color:#C4161C; color:#fff;border-radius:2px;" class="btn">Delete</button>
                            </div>
                        </div>
                    </div>
                </div>

                
                    <div class="col-md-9 col-xs-12">
                        <div class="white-box">
                            <div class="row">
                                        <div class="col-md-3 col-xs-6 b-r"> <strong>Full Name</strong>
                                            <br>
                                            <p class="text-muted"><?php echo e($patient->patientname); ?></p>
                                        </div>
                                        <div class="col-md-3 col-xs-6 b-r"> <strong>Mobile</strong>
                                            <br>
                                            <p class="text-muted"><?php echo e($patient->patientmobile); ?></p>
                                        </div>
                                        <div class="col-md-3 col-xs-6 b-r"> <strong>Email</strong>
                                            <br>
                                            <p class="text-muted"><?php echo e($patient->patientemail); ?></p>
                                        </div>
                                        <div class="col-md-3 col-xs-6 b-r"> <strong>PID</strong>
                                            <br>
                                            <p class="text-muted"><?php echo e($patient->id); ?>-<?php echo e($date); ?></p>
                                        </div>
                                        <!-- <div class="col-md-3 col-xs-6"> <strong>Disease</strong>
                                            <br>
                                            <p class="text-muted">Fever</p>
                                        </div> -->
                                    </div>
                                    <div style = "display:flex">
                                        <div style = "width:50%;">
                                                    <h4 class="m-t-30">Patient Profile</h4>
                                            <div style = "display:flex;">
                                                    <p class="m-t-10">Salutation:</p>
                                                    <p class="m-t-10 m-l-5"><?php echo e($patient->patientsalutation); ?></p>
                                            </div>
                                            <div style = "display:flex;">
                                                    <p class="m-t-10">First Name:</p> 
                                                    <p class="m-t-10 m-l-5"><?php echo e($patient->patientfirstname); ?></p>
                                            </div>
                                            <div style = "display:flex;">
                                                    <p class="m-t-10">Last Name:</p>
                                                    <p class="m-t-10 m-l-5"><?php echo e($patient->patientlastname); ?></p>
                                            </div>
                                            <div style = "display:flex;">
                                                    <p class="m-t-10">DOB:</p>
                                                    <p class="m-t-10 m-l-5"><?php echo e($patient->patientDOB); ?></p>
                                            </div>

                                             <div style = "display:flex;">
                                                    <p class="m-t-10">Martial Status:</p>
                                                    <p class="m-t-10 m-l-5"><?php echo e($patient->patientmartialstatus); ?></p>
                                            </div>
                                            <div style = "display:flex;">
                                                    <p class="m-t-10">Gender:</p>
                                                    <p class="m-t-10 m-l-5"><?php echo e($patient->patientgen); ?></p>
                                            </div>
                                            <div style = "display:flex;">
                                                    <p class="m-t-10">Occupation:</p>
            
                                                    <p class="m-t-10 m-l-5"><?php echo e($patient->patientoccupation); ?></p>
                                            </div>
                                            <div style = "display:flex;">
                                                    <p class="m-t-10">Mobile:</p>
                                                    <p class="m-t-10 m-l-5"><?php echo e($patient->patientmobile); ?></p>
                                            </div>
                                            <div style = "display:flex;">
                                                    <p class="m-t-10">Email:</p>
                                                    <p class="m-t-10 m-l-5"><?php echo e($patient->patientemail); ?></p>
                                            </div>
                                            <div style = "display:flex;">
                                                    <p class="m-t-10">Address:</p>
                                                    <p class="m-t-10 m-l-5"><?php echo e($patient->patientaddress); ?></p>
                                            </div>
                                            <div style = "display:flex;">
                                                    <p class="m-t-10">Residence City:</p>
                                                    <p class="m-t-10 m-l-5"><?php echo e($patient->patientcity); ?></p>
                                            </div>
                                            <div style = "display:flex;">
                                                    <p class="m-t-10">Country:</p>
                                                    <p class="m-t-10 m-l-5"><?php echo e($patient->patientcountry); ?></p>
                                            </div>
                                            <div style = "display:flex;">
                                                    <p class="m-t-10">Nationality:</p>
                                                    <p class="m-t-10 m-l-5"><?php echo e($patient->patientnationality); ?></p>
                                            </div>
                                            <div style = "display:flex;">
                                                    <p class="m-t-10">Therapist:</p>
                                                    <p class="m-t-10 m-l-5"><?php echo e($patient->patienttherapist); ?></p>
                                            </div>
                                                    
                                            
                                        </div>
                                        <div style = "width:50%;">
                                            <h4 class="m-t-30">Exercise History</h4>
                                            <table>
                                                <tr>
                                                    <th style = "width:32%;">Exercise Title</th>
                                                    <th style = "width:25%;">Therapist</th>
                                                    <th style = "width:25%;">Given on</th>
                                                    <th style = "width:25%;">Expire On</th>
                                                    
                                                </tr>
                                                <?php $__currentLoopData = $shareexercise; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $share): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                        <td><?php echo e($share->exercise); ?></td>
                                                        <td><?php echo e($share->adminname); ?></td>
                                                        <td><?php echo e($share->given_date); ?></td>
                                                        <td><?php echo e($share->expire_date); ?></td>                                                    
                                                </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </table>
                                        </div>
                                            <!-- <hr>
                                            <p class="m-t-30">Donec pede justo, fringilla vel, aliquet nec, vulputate eget, arcu. In enim justo, rhoncus ut, imperdiet a, venenatis vitae, justo. Nullam dictum felis eu pede mollis pretium. Integer tincidunt.Cras dapibus. Vivamus elementum semper nisi. Aenean vulputate eleifend tellus. Aenean leo ligula, porttitor eu, consequat vitae, eleifend ac, enim.</p>
                                            <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries </p>
                                            <p>It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p> -->
                                            <!-- <h4 class="m-t-30">Exercise History</h4> -->
                                            <!-- <hr>
                                            <p class="m-t-30">Donec pede justo, fringilla vel, aliquet nec, vulputate eget, arcu. In enim justo, rhoncus ut, imperdiet a, venenatis vitae, justo. Nullam dictum felis eu pede mollis pretium. Integer tincidunt.Cras dapibus. Vivamus elementum semper nisi. Aenean vulputate eleifend tellus. Aenean leo ligula, porttitor eu, consequat vitae, eleifend ac, enim.</p>
                                            <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries </p>
                                            <p>It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p> -->
                                    </div>
                                    
                        </div>
                    </div>
                    <div class="row">
                    <div class="col-md-3 col-xs-12">
                        <div class="white-box">
                            
                            <div class="user-bg"> <img width="70%" height="100%" style = "margin-left:15%; border-radius:50%;" alt="user" id ="preview" src=<?php echo e($patient->filelink); ?>> </img> </div>
                            <div class="user-btm-box">
                                <!-- .row -->
                                <hr>
                                <div class="row text-center m-t-10">
                                    <div class="col-md-12"><strong>Portal Access:</strong>&nbsp;&nbsp;&nbsp;&nbsp;
                                        <label class="switch" style = "vertical-align: middle;">
                                            <input type="checkbox" class="portalaccess" 
                                                        <?php if($patient->portal == 1): ?>
                                                            checked
                                                        <?php else: ?>
                                                        <?php endif; ?>>
                                            <span class="slider round"></span>
                                        </label>
                                    </div>
                                <input type="hidden" class="portalid" value=<?php echo e($patient->id); ?>>
                                
                                </div>

                                <hr>
                                <div class="row text-center m-t-10">
                                    <!-- <p>Access expires on: April 30,2018</p> -->
                                    <p>Registered on: March 30,2018</p>
                                </div>
                                <hr>
                                <div class="row text-center m-t-10">
                                    <div class="col-md-12"><strong>System Role:</strong> &nbsp;Patient
                                        <!-- <p>Patient</p> -->
                                    </div>
                                </div>
                                <hr>
                                <div class="row text-center m-t-10">
                                    <div class="col-md-12">
                                        <a href="#" data-toggle="modal" data-target="#exampleModal" class = "resetportal">Reset Portal Password</a>
                                        <!-- URL::route('logout') -->
                                    </div>
                                </div>
                                
                                <hr>
                               
                            </div>
                        </div>
                    </div>
                </div>
                
                <form class="form-horizontal" method="GET" action="/patientforgotpassword">
                    <?php echo e(csrf_field()); ?>

                    <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                        <div class="modal-dialog" role="document">
                            <div class="modal-content" style = "width:380px;">
                                <div class="modal-header wrapper">
                                    <h5 class="modal-title" id="exampleModalLabel">Reset Password</h5>
                                </div>
                                
                                    <input type="hidden" id="email" type="email" class="form-control" name="email" value="<?php echo e($patient->patientemail); ?>">
                                    
                                
                                <div class="modal-footer wrapper" style = "text-align:center;">
                                    <!-- <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button> -->
                                    
                                    <button type="submit" class="btn btn-primary">Confirm & Send Reset Password</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </form>

               
            </div>
            <!-- /.container-fluid -->
            <footer class="footer text-center">   </footer>
        </div>
        <!-- /#page-wrapper -->
    </div>
    <!-- /#wrapper -->
    
    <?php echo $__env->make('script', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</body>
<script>
    $('.portalaccess').click(function(){
        var index = $('.portalid').val();
        
        location.href= "/updateportalaccess/" + index;
    });
   
</script>
</html>
